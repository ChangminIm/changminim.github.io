# -*- coding: utf-8 -*-
"""8주차 실습 2 도우미: 공주 Sentinel-2 패치(patch, 32×32 화소 = 320 m)를 토지피복 네 가지로 분류하는 작은 CNN과 기여도 지도(attribution map) 방법
패치 추출, 학습/평가 구역, 학습 순서, 무작위 삭제 순서의 시드를 고정하고 스레드를 1개로 두어 모든 학생이 같은 값을 얻게 함.
"""
from pathlib import Path
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F

CLASSES = ["산림", "농경지", "시가지", "수역"]
BANDS = ["B2 파랑", "B3 초록", "B4 빨강", "B8 근적외"]
WC_MAP = {10: 0, 40: 1, 50: 2, 80: 3, 90: 3, 95: 3}        # WorldCover → 네 클래스 (초지·나지 등은 쓰지 않음)
PS, STRIDE, NBLOCK = 32, 16, 6                              # 패치 크기, 간격(화소), 구역 격자
TEST_BLOCKS = {(i, j) for i in range(NBLOCK) for j in range(NBLOCK) if (i + 2 * j) % 3 == 0}   # 36구역 중 12구역이 평가용
CAP = {"train": 600, "test": 300}                           # 클래스별 패치 수 상한 (산림이 너무 많아 맞춤)


def make_patches(data_dir="."):
    """영상을 6×6 구역으로 나누고 구역 안에서 32×32 패치를 16화소 간격으로 자름. 패치의 라벨 = 가장 넓은 피복(네 클래스 중).
    네 클래스가 패치의 60% 이상을 덮는 패치만 씀. 학습/평가는 구역 단위로 나눠 같은 화소가 양쪽에 들어가지 않게 함.
    반환 dict: X(N×4×32×32 반사율), y(N), L(N×32×32 화소별 라벨, 네 클래스 밖은 255), purity(가장 넓은 피복의 비율),
    share(N×4 피복 비율), test(N, True면 평가용), rc(N×2 패치 왼쪽 위 행·열)"""
    import rasterio
    d = Path(data_dir)
    with rasterio.open(d / "kongju_s2.tif") as r:
        s2 = r.read().astype("float32") / 10000.0
    with rasterio.open(d / "kongju_wc.tif") as r:
        wc = r.read(1)
    lab = np.full(wc.shape, 255, "uint8")
    for k, v in WC_MAP.items():
        lab[wc == k] = v
    H, W = lab.shape; bh, bw = H // NBLOCK, W // NBLOCK
    rows = []
    for bi in range(NBLOCK):
        for bj in range(NBLOCK):
            for r0 in range(bi * bh, (bi + 1) * bh - PS + 1, STRIDE):
                for c0 in range(bj * bw, (bj + 1) * bw - PS + 1, STRIDE):
                    p = lab[r0:r0 + PS, c0:c0 + PS]
                    sh = np.array([(p == k).mean() for k in range(4)])
                    if sh.sum() >= 0.6:
                        rows.append((r0, c0, int(sh.argmax()), sh.max() / sh.sum(), (bi, bj) in TEST_BLOCKS, *sh))
    A = np.array(rows, dtype=float); rng = np.random.default_rng(0); keep = []
    for is_test, cap in ((0, CAP["train"]), (1, CAP["test"])):
        for k in range(4):
            idx = np.where((A[:, 4] == is_test) & (A[:, 2] == k))[0]
            keep.extend(sorted(rng.choice(idx, cap, replace=False)) if len(idx) > cap else idx)
    A = A[np.array(sorted(keep))]
    X = np.stack([s2[:, int(r0):int(r0) + PS, int(c0):int(c0) + PS] for r0, c0 in A[:, :2]])
    L = np.stack([lab[int(r0):int(r0) + PS, int(c0):int(c0) + PS] for r0, c0 in A[:, :2]])
    return {"X": X, "y": A[:, 2].astype(int), "L": L, "purity": A[:, 3], "share": A[:, 5:9], "test": A[:, 4].astype(bool), "rc": A[:, :2].astype(int)}


class SmallCNN(nn.Module):
    """합성곱 3층 + 전역 평균 풀링 + 선형층. 입력은 반사율 그대로이고 정규화(밴드별 평균·표준편차)는 모델 안에서 함"""

    def __init__(self, mean, std, n_classes=4):
        super().__init__()
        self.register_buffer("mean", torch.tensor(mean, dtype=torch.float32).view(1, -1, 1, 1))
        self.register_buffer("std", torch.tensor(std, dtype=torch.float32).view(1, -1, 1, 1))
        self.features = nn.Sequential(nn.Conv2d(4, 16, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                                      nn.Conv2d(16, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
                                      nn.Conv2d(32, 64, 3, padding=1), nn.ReLU())           # 마지막 특징 맵(feature map): 64장 × 8×8
        self.head = nn.Linear(64, n_classes)

    def feat(self, x):
        return self.features((x - self.mean) / self.std)

    def forward(self, x):
        return self.head(self.feat(x).mean((2, 3)))


def train_cnn(data, epochs=20):
    """학습용 패치로 SmallCNN을 학습함. 시드 0, 스레드 1개, 배치 64, Adam(학습률 0.002). 반환: 학습한 모델(평가 상태)"""
    torch.set_num_threads(1); torch.manual_seed(0); torch.use_deterministic_algorithms(True)
    tr = ~data["test"]; X = torch.tensor(data["X"][tr]); y = torch.tensor(data["y"][tr])
    model = SmallCNN(X.mean((0, 2, 3)).tolist(), X.std((0, 2, 3)).tolist())
    opt = torch.optim.Adam(model.parameters(), lr=2e-3); g = torch.Generator().manual_seed(0)
    for ep in range(epochs):
        model.train(); perm = torch.randperm(len(X), generator=g)
        for i in range(0, len(X), 64):
            b = perm[i:i + 64]; opt.zero_grad(); F.cross_entropy(model(X[b]), y[b]).backward(); opt.step()
    return model.eval()


def rgb(x):
    """패치나 영상(4×H×W 반사율)을 화면에 그릴 자연색(H×W×3, 0~1)으로 바꿈. 밝기 범위는 전체 영상의 2~98%로 고정"""
    lo = np.array([0.1325, 0.1543, 0.1348]); hi = np.array([0.3094, 0.2840, 0.2582])
    a = np.moveaxis(np.asarray(x)[[2, 1, 0]], 0, -1)
    return np.clip((a - lo) / (hi - lo), 0, 1)


def predict(model, X):
    """패치들의 클래스별 확률(N×4)"""
    torch.set_num_threads(1)
    with torch.no_grad():
        return torch.softmax(model(torch.as_tensor(np.asarray(X), dtype=torch.float32)), 1).numpy()


def score(model, x=None):
    """패치 하나의 클래스 점수(logit, 소프트맥스 앞의 값) 4개. x를 주지 않으면 기준 입력(baseline, 모든 화소가 밴드 평균인 영상)의 점수"""
    torch.set_num_threads(1)
    z = model.mean.expand(1, 4, PS, PS) if x is None else torch.as_tensor(np.asarray(x), dtype=torch.float32).unsqueeze(0)
    with torch.no_grad():
        return model(z)[0].numpy()


def explain(model, x, method, target=None):
    """패치 하나(4×32×32)의 기여도 지도(attribution map). target을 주지 않으면 모델이 고른 클래스를 설명함. 네 방법 모두 그 클래스의 점수(logit)를 설명함.
    'occlusion'  가림 민감도(occlusion sensitivity): 8×8 칸을 밴드 평균으로 가렸을 때 그 클래스의 점수가 떨어진 양 (4화소씩 옮겨 가며, 겹치는 곳은 평균). 반환 32×32
    'gradient'   기울기 지도(saliency map): 화소 값을 조금 바꿀 때 점수가 변하는 정도의 절댓값. 반환 4×32×32
    'ig'         Integrated Gradients(적분 기울기): 기준 입력(밴드 평균 영상)에서 실제 영상까지 50단계로 바꿔 가며 기울기를 누적. 합 = 점수 차이. 반환 4×32×32
    'gradcam'    Grad-CAM: 마지막 특징 맵 64장을 기울기 평균으로 가중합하고 음수를 0으로. 8×8을 32×32로 늘림. 반환 32×32
    (수업에서 쓰지 않는 선택 사항) 'gradxinput' 기울기 × (입력 − 평균). 반환 4×32×32"""
    torch.set_num_threads(1)
    x = torch.as_tensor(np.asarray(x), dtype=torch.float32).unsqueeze(0); base = model.mean.expand_as(x).clone()
    if target is None:
        target = int(model(x).argmax(1))
    if method == "occlusion":
        with torch.no_grad():
            p0 = model(x)[0, target].item()
        acc = np.zeros((PS, PS)); cnt = np.zeros((PS, PS)); xs = []; pos = []
        for r in range(0, PS - 8 + 1, 4):
            for c in range(0, PS - 8 + 1, 4):
                z = x.clone(); z[:, :, r:r + 8, c:c + 8] = base[:, :, r:r + 8, c:c + 8]; xs.append(z); pos.append((r, c))
        with torch.no_grad():
            p = model(torch.cat(xs))[:, target].numpy()
        for (r, c), v in zip(pos, p):
            acc[r:r + 8, c:c + 8] += p0 - v; cnt[r:r + 8, c:c + 8] += 1
        return acc / cnt
    if method in ("gradient", "gradxinput"):
        z = x.clone().requires_grad_(True); model(z)[0, target].backward(); g = z.grad[0]
        return (g.abs() if method == "gradient" else g * (x - base)[0]).numpy()
    if method == "ig":
        tot = torch.zeros_like(x)
        for a in (np.arange(50) + 0.5) / 50:
            z = (base + a * (x - base)).requires_grad_(True); model(z)[0, target].backward(); tot += z.grad
        return ((x - base) * tot / 50)[0].numpy()
    if method == "gradcam":
        f = model.feat(x); f.retain_grad(); model.head(f.mean((2, 3)))[0, target].backward()
        cam = F.relu((f.grad.mean((2, 3), keepdim=True) * f).sum(1, keepdim=True))
        return F.interpolate(cam, size=(PS, PS), mode="bilinear", align_corners=False)[0, 0].detach().numpy()
    raise ValueError(method)


def pick_correct(D, model, n_per_class=50):
    """평가 패치 중 모델이 맞힌 패치를 클래스마다 n_per_class개씩 시드 0으로 뽑아 번호(전체 배열 기준)를 돌려줌"""
    idx = np.where(D["test"])[0]; ok = idx[predict(model, D["X"][idx]).argmax(1) == D["y"][idx]]; rng = np.random.default_rng(0)
    return np.sort(np.concatenate([rng.choice(ok[D["y"][ok] == k], n_per_class, replace=False) for k in range(4)]))


def to_map(attr):
    """기여도 지도를 32×32 '화소 기여도'로 바꿈: 밴드가 있으면 밴드 합의 양수 부분(기울기는 밴드 합)"""
    a = np.asarray(attr)
    return a if a.ndim == 2 else np.maximum(a.sum(0), 0)


def deletion_curve(model, X, maps, steps=10, seed=None):
    """삭제 곡선(deletion curve, pixel flipping): 기여도가 높은 화소부터 10%씩 밴드 평균으로 바꾸며, 처음에 고른 클래스의 확률이 어떻게 떨어지는지 평균함.
    maps: 패치별 32×32 기여도. seed를 주면 maps 대신 무작위 순서(그 시드)를 씀. 반환: 길이 steps+1의 평균 확률 (삭제 0%~100%)"""
    torch.set_num_threads(1)
    X = torch.as_tensor(np.asarray(X), dtype=torch.float32); n = len(X); base = model.mean.expand(1, 4, PS, PS)
    with torch.no_grad():
        tgt = model(X).argmax(1)
    rng = np.random.default_rng(seed) if seed is not None else None
    order = np.stack([rng.permutation(PS * PS) if rng is not None else np.argsort(-np.asarray(maps[i]).ravel(), kind="stable") for i in range(n)])
    out = []
    for s in range(steps + 1):
        k = int(round(PS * PS * s / steps)); Z = X.clone()
        if k:
            m = torch.zeros(n, PS * PS, dtype=torch.bool); m[torch.arange(n).unsqueeze(1), torch.as_tensor(order[:, :k].copy())] = True
            Z = torch.where(m.view(n, 1, PS, PS), base, Z)
        with torch.no_grad():
            out.append(float(torch.softmax(model(Z), 1)[torch.arange(n), tgt].mean()))
    return np.array(out)


def mask_hit(maps, L, y, top=0.2):
    """라벨 일치도: 기여도 지도에서 기여도 상위 20% 화소 가운데, 라벨이 그 패치의 클래스인 화소의 비율(패치 평균). 무작위로 고르면 그 클래스의 면적 비율이 나옴"""
    k = int(PS * PS * top); out = []
    for m, l, c in zip(maps, L, y):
        out.append(float((np.asarray(l).ravel()[np.argsort(-np.asarray(m).ravel(), kind="stable")[:k]] == c).mean()))
    return float(np.mean(out))


def band_occlusion(model, X, y):
    """밴드 가림(band occlusion): 밴드 하나를 그 밴드의 평균값으로 바꿨을 때 정확도. 반환: 원래 정확도, 밴드별 정확도(4)"""
    X = np.asarray(X, dtype="float32"); y = np.asarray(y)
    acc0 = float((predict(model, X).argmax(1) == y).mean()); out = []
    for b in range(4):
        Z = X.copy(); Z[:, b] = float(model.mean[0, b]); out.append(float((predict(model, Z).argmax(1) == y).mean()))
    return acc0, out
