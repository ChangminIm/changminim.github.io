# -*- coding: utf-8 -*-
"""7주차 실습 2 도우미: 시군구 우울 패널로 GWR·MGWR·GTWR·MGTWR·ESF·ESF-SVC 맞추기
모든 함수는 난수를 쓰지 않음. 설정(커널, 대역폭 탐색 범위, 고유벡터 기준)을 고정해 모든 학생이 같은 값을 얻게 함.
"""
from pathlib import Path
import numpy as np
import pandas as pd

TOL_MULTI = 1e-3                                                                         # MGTWR 수렴 기준
VARS = ["ndvi", "single_young", "welfare_rate", "old_house", "fiscal_ind"]
LABEL = {"ndvi": "녹지(NDVI)", "single_young": "청년 1인 가구", "welfare_rate": "기초생활수급",
         "old_house": "노후 주택", "fiscal_ind": "재정자립도"}


def load(data_dir="data"):
    """패널(2,052행), 인접 행렬 W(229×229, 0/1), 경계(GeoDataFrame)를 읽음. W의 행 순서 = codes"""
    import geopandas as gpd
    d = Path(data_dir)
    df = pd.read_csv(d / "depression_panel.csv", encoding="utf-8-sig", dtype={"SIG_CD": str})
    Wdf = pd.read_csv(d / "W_queen_bridge.csv", encoding="utf-8-sig", index_col=0)
    Wdf.index = Wdf.index.astype(str); Wdf.columns = Wdf.columns.astype(str)
    codes = list(Wdf.index)
    gdf = gpd.read_file(d / "sigungu229.geojson")
    gdf["SIG_CD"] = gdf.SIG_CD.astype(str)
    return df, Wdf.values.astype(float), codes, gdf


def standardize(df, vars=VARS, y="dep_ma3"):
    """전체 패널의 평균·표준편차로 표준화. 계수는 '1 표준편차당 변화(표준편차 단위)'로 읽음"""
    X = df[vars].values.astype(float)
    X = (X - X.mean(0)) / X.std(0)
    yy = df[[y]].values.astype(float)
    yy = (yy - yy.mean()) / yy.std()
    return X, yy


def moran_I(v, W):
    """행 표준화한 W로 Moran's I"""
    Wr = W / np.maximum(W.sum(1, keepdims=True), 1)
    z = np.asarray(v, float).ravel(); z = z - z.mean()
    return float(len(z) / Wr.sum() * (z @ Wr @ z) / (z @ z))


def fit_gwr(coords, X, y, multi=False):
    """mgwr로 GWR(multi=False) 또는 MGWR(multi=True). 적응형 bisquare, AICc로 대역폭 선택.
    반환: betas(n×(1+p), 첫 열 절편), bw(GWR은 숫자, MGWR은 변수별 배열), R2, AICc, resid"""
    from mgwr.sel_bw import Sel_BW
    from mgwr.gwr import GWR, MGWR
    sel = Sel_BW(coords, y, X, kernel="bisquare", fixed=False, multi=multi)
    if multi:
        bw = sel.search(criterion="AICc", multi_bw_min=[20])
        r = MGWR(coords, y, X, sel, kernel="bisquare", fixed=False).fit()
    else:
        bw = sel.search(criterion="AICc")
        r = GWR(coords, y, X, bw, kernel="bisquare", fixed=False).fit()
    e = r.resid_response.ravel()
    return {"betas": r.params, "bw": np.asarray(bw).ravel() if multi else float(bw), "R2": float(r.R2),
            "k": float(r.tr_S), "AICc": aicc(e, r.tr_S), "resid": e}


def fit_gtwr(coords, t, X, y, multi=False):
    """mgtwr로 GTWR(multi=False) 또는 MGTWR(multi=True). 적응형 bisquare, AICc.
    시공간 거리 d² = (공간 거리 km)² + τ × (연도 차)². τ는 0~100에서 찾음.
    반환: betas, bw, tau(MGTWR은 변수별), R2, AICc, resid"""
    from mgtwr.sel import SearchGTWRParameter, SearchMGTWRParameter
    from mgtwr.model import GTWR, MGTWR
    t = np.asarray(t, float).reshape(-1, 1)
    if multi:
        sel = SearchMGTWRParameter(coords, t, X, y, kernel="bisquare", fixed=False)
        bws = sel.search(tau_max=100, multi_bw_min=[20], multi_tau_max=[100], tol_multi=TOL_MULTI)
        r = MGTWR(coords, t, X, y, sel, kernel="bisquare", fixed=False).fit()
        e = np.asarray(r.reside).ravel()
        return {"betas": r.betas, "bw": np.asarray(bws[0]).ravel(), "tau": np.asarray(bws[1]).ravel(),
                "R2": float(r.R2), "k": float(r.tr_S), "AICc": aicc(e, r.tr_S), "resid": e}
    sel = SearchGTWRParameter(coords, t, X, y, kernel="bisquare", fixed=False)
    bw, tau = sel.search(tau_max=100)
    r = GTWR(coords, t, X, y, bw, tau, kernel="bisquare", fixed=False).fit()
    e = np.asarray(r.reside).ravel()
    return {"betas": r.betas, "bw": float(bw), "tau": float(tau), "R2": float(r.R2), "k": float(r.tr_S),
            "AICc": aicc(e, r.tr_S), "resid": e}


def moran_eigenvectors(W, threshold=0.25):
    """무어 고유벡터: M W M (M = 중심화 행렬)의 고유벡터 중 양의 공간 자기상관이 큰 것.
    고유값/최대 고유값 ≥ threshold인 것만 남김. 반환: E(229×L, 큰 패턴부터), 고유값"""
    n = W.shape[0]; Ws = (W + W.T) / 2
    M = np.eye(n) - np.ones((n, n)) / n
    val, vec = np.linalg.eigh(M @ Ws @ M)
    o = np.argsort(val)[::-1]; val, vec = val[o], vec[:, o]
    keep = val / val[0] >= threshold
    vec = vec[:, keep] * np.sign(vec[:, keep].sum(0) + 1e-12)       # 부호를 고정해 지도가 학생마다 뒤집히지 않게 함
    return vec, val[keep]


def aicc(resid, k):
    """모든 모델에 같은 식을 씀(mgwr과 같은 식): n·ln(2π·RSS/n) + n(n+k)/(n−2−k). k = 모수 수 또는 유효 모수 수 tr(S)"""
    e = np.ravel(resid); n = len(e); rss = float(e @ e)
    return float(n * np.log(2 * np.pi * rss / n) + n * (n + k) / (n - 2 - k))


def _ols(y, Z):
    beta, *_ = np.linalg.lstsq(Z, y, rcond=None)
    e = y - Z @ beta; rss = float(e @ e)
    return beta, e, rss, aicc(e, Z.shape[1])


def year_dummies(year):
    yrs = np.sort(np.unique(year))
    return np.column_stack([(year == v).astype(float) for v in yrs[1:]])


def fit_ols(X, y, year):
    """OLS + 연도 더미. 반환: 계수(절편, 변수), R2, AICc, resid"""
    y = np.ravel(y); Z = np.column_stack([np.ones(len(y)), X, year_dummies(year)])
    b, e, rss, ac = _ols(y, Z)
    return {"coef": b[:1 + X.shape[1]], "R2": 1 - rss / ((y - y.mean()) @ (y - y.mean())), "k": Z.shape[1], "AICc": ac, "resid": e}


def fit_esf(X, y, year, E_rows):
    """ESF: OLS + 연도 더미에 무어 고유벡터를 하나씩 더하며 AICc가 줄어드는 동안 고름(전진 선택).
    E_rows: 각 행(시군구-연도)의 고유벡터 값(n×L). 반환: 계수, 고른 고유벡터 번호, R2, AICc, resid, 공간 필터 값"""
    y = np.ravel(y); base = np.column_stack([np.ones(len(y)), X, year_dummies(year)])
    chosen, cur = [], _ols(y, base)[3]
    while True:
        best = None
        for j in range(E_rows.shape[1]):
            if j in chosen: continue
            a = _ols(y, np.column_stack([base, E_rows[:, chosen + [j]]]))[3]
            if best is None or a < best[1]: best = (j, a)
        if best is None or best[1] >= cur: break
        chosen.append(best[0]); cur = best[1]
    Z = np.column_stack([base, E_rows[:, chosen]]); b, e, rss, ac = _ols(y, Z)
    sf = E_rows[:, chosen] @ b[base.shape[1]:] if chosen else np.zeros(len(y))
    return {"coef": b[:1 + X.shape[1]], "chosen": chosen, "R2": 1 - rss / ((y - y.mean()) @ (y - y.mean())),
            "k": Z.shape[1], "AICc": ac, "resid": e, "filter": sf}


def fit_esf_svc(X, y, year, E_rows, L=10):
    """ESF 계수 변동 모델(단순판): 각 변수의 계수 = 공통값 + 큰 고유벡터 L개의 조합.
    β_k(i) = b_k + Σ_l E_il γ_kl. 고유벡터 L개는 절편에도 넣음. 반환: betas(n×(1+p)), R2, AICc, resid"""
    y = np.ravel(y); n, p = X.shape; E = E_rows[:, :L]
    cols = [np.ones(n), *X.T, *E.T, *[X[:, k:k + 1] * E for k in range(p)]]
    Z = np.column_stack([np.column_stack(cols), year_dummies(year)])
    b, e, rss, ac = _ols(y, Z)
    betas = np.zeros((n, 1 + p)); betas[:, 0] = b[0] + E @ b[1 + p:1 + p + L]
    for k in range(p):
        g = b[1 + p + L + k * L:1 + p + L + (k + 1) * L]
        betas[:, 1 + k] = b[1 + k] + E @ g
    return {"betas": betas, "R2": 1 - rss / ((y - y.mean()) @ (y - y.mean())), "k": Z.shape[1], "AICc": ac, "resid": e}
