# -*- coding: utf-8 -*-
"""10주차 실습 도우미: 공주 거리 사진(Mapillary, CC BY-SA 4.0)을 SegFormer로 시맨틱 세그멘테이션해 녹시율(Green View Index)을 구함
모델은 HuggingFace의 nvidia/segformer-b0-finetuned-cityscapes-1024-1024 (Cityscapes 19 클래스). 처음 실행할 때 약 15 MB를 받음.
추론만 하므로 난수가 없음. 스레드 수를 1개로 고정해 모든 학생이 같은 값을 얻게 함.
"""
from pathlib import Path
import numpy as np
import pandas as pd

MODEL_ID = "nvidia/segformer-b0-finetuned-cityscapes-1024-1024"
CLASSES = ["도로", "보도", "건물", "벽", "울타리", "기둥", "신호등", "표지판", "식생", "지면",
           "하늘", "사람", "자전거 탄 사람", "승용차", "트럭", "버스", "기차", "오토바이", "자전거"]
EN = ["road", "sidewalk", "building", "wall", "fence", "pole", "traffic light", "traffic sign", "vegetation", "terrain",
      "sky", "person", "rider", "car", "truck", "bus", "train", "motorcycle", "bicycle"]
VEG, TERRAIN, SKY = 8, 9, 10
PALETTE = np.array([[128, 64, 128], [244, 35, 232], [70, 70, 70], [102, 102, 156], [190, 153, 153], [153, 153, 153], [250, 170, 30],
                    [220, 220, 0], [107, 142, 35], [152, 251, 152], [70, 130, 180], [220, 20, 60], [255, 0, 0], [0, 0, 142],
                    [0, 0, 70], [0, 60, 100], [0, 80, 100], [0, 0, 230], [119, 11, 32]], dtype=np.uint8)   # Cityscapes 표준 색


def load_photos(data_dir="data"):
    """사진 목록(data/photos.csv)을 읽고 파일 경로 열(path)을 붙임. 열: id, lon, lat, captured_at, compass, creator, sequence, path"""
    d = Path(data_dir)
    P = pd.read_csv(d / "photos.csv", encoding="utf-8-sig", dtype={"id": str, "sequence": str})
    P["path"] = [str(d / "images" / f"{i}.jpg") for i in P.id]
    return P


def load_model():
    """SegFormer-b0(Cityscapes)와 전처리기를 받아 평가 상태로 돌려줌. 스레드 1개로 고정"""
    import torch
    from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
    torch.set_num_threads(1)
    proc = SegformerImageProcessor.from_pretrained(MODEL_ID)
    model = SegformerForSemanticSegmentation.from_pretrained(MODEL_ID).eval()
    return proc, model


def segment(proc, model, path):
    """사진 한 장의 화소별 클래스 번호(H×W, 0~18)를 돌려줌. 모델 출력(1/4 크기)을 사진 크기로 늘린 뒤 가장 점수가 높은 클래스를 고름"""
    import torch
    import torch.nn.functional as F
    from PIL import Image
    img = Image.open(path).convert("RGB")
    with torch.no_grad():
        x = proc(images=img, return_tensors="pt")
        logits = model(**x).logits
        up = F.interpolate(logits, size=img.size[::-1], mode="bilinear", align_corners=False)
    return up.argmax(1)[0].numpy().astype(np.uint8)


def class_share(label):
    """클래스별 화소 비율(합 1) 19개를 dict로 돌려줌 (키는 영어 클래스 이름)"""
    cnt = np.bincount(label.ravel(), minlength=19) / label.size
    return dict(zip(EN, cnt.round(5).tolist()))


def green_view_index(label):
    """녹시율(Green View Index) = 사진에서 식생(vegetation) 클래스가 차지하는 화소 비율"""
    return float((label == VEG).mean())


def overlay(path, label, alpha=0.55):
    """사진 위에 클래스 색을 겹친 그림(H×W×3, 0~255)"""
    from PIL import Image
    img = np.asarray(Image.open(path).convert("RGB"), dtype=float)
    return (img * (1 - alpha) + PALETTE[label] * alpha).astype(np.uint8)


def overhead_green(photos, wc_path="data/kongju_wc.tif", radius_m=30):
    """위에서 본 녹지 비율: ESA WorldCover 2021(10 m)에서 사진 위치 반경 radius_m 안의 나무(10)·초지(30) 화소 비율"""
    import rasterio
    from pyproj import Transformer
    with rasterio.open(wc_path) as r:
        wc = r.read(1); tf = r.transform; crs = r.crs
    to = Transformer.from_crs("EPSG:4326", crs, always_xy=True)
    xs, ys = to.transform(photos.lon.values, photos.lat.values)
    k = int(np.ceil(radius_m / 10)); yy, xx = np.mgrid[-k:k + 1, -k:k + 1]; disk = (np.hypot(yy, xx) * 10 <= radius_m)
    out = []
    for x, y in zip(xs, ys):
        c, rr = ~tf * (x, y); c, rr = int(c), int(rr)
        win = wc[max(rr - k, 0):rr + k + 1, max(c - k, 0):c + k + 1]
        m = disk[:win.shape[0], :win.shape[1]]
        out.append(float(np.isin(win[m], [10, 30]).mean()) if m.any() else np.nan)
    return np.array(out)
