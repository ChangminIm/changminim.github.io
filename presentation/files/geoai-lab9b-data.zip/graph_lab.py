# -*- coding: utf-8 -*-
"""10주차 실습 2 도우미: 서울 도시고속도로·고속국도 링크 1,679개의 10분 통행속도(ITS 국가교통정보센터, 2025-10-13~19)로
도로망 그래프를 만들고, ① 다음 시각 예측과 ② 자료가 빈 링크 채우기에서 이웃 링크 정보가 얼마나 도움이 되는지 잼.
학습은 월~목(10/13~16), 평가는 금요일(10/17). 모델은 릿지 회귀(난수 없음)라 모든 학생이 같은 값을 얻음.
"""
from pathlib import Path
import numpy as np
import pandas as pd

TRAIN_END = "2025-10-17"; TEST_DAY = "2025-10-17"; STEP = 10                 # 10분 칸


def load(data_dir="data"):
    """속도 표(행: 10분 시각 1,008개, 열: 링크 1,679개, 빈칸 = 자료 없음)와 링크(GeoDataFrame, WGS84)를 읽음"""
    import geopandas as gpd
    d = Path(data_dir)
    S = pd.read_csv(d / "speed_10min.csv", index_col="time", parse_dates=True)
    links = gpd.read_file(d / "links.geojson")
    for c in ("LINK_ID", "F_NODE", "T_NODE", "ROAD_RANK"): links[c] = links[c].astype(str)
    links = links.set_index("LINK_ID").loc[list(S.columns)].reset_index()
    return S, links


def fill_gaps(S):
    """빈 10분 칸을 앞뒤 값으로 메움(선형 보간, 최대 6칸 = 1시간). 반환: 채운 표, 시각별 '원래 자료가 있었나'(bool)"""
    obs = S.notna().any(axis=1).values
    return S.interpolate(limit=6, limit_direction="both").ffill().bfill(), obs


def build_graph(links):
    """도로망 그래프: 링크 A의 끝 노드(T_NODE) = 링크 B의 시작 노드(F_NODE)이면 B는 A의 하류(downstream), A는 B의 상류(upstream).
    같은 두 노드를 반대로 잇는 링크(반대 방향 차로)는 이웃에서 뺌. 반환: down, up (링크 번호 목록의 목록)"""
    fn, tn = links.F_NODE.values, links.T_NODE.values; idx = pd.Series(range(len(links)))
    by_f = idx.groupby(fn).apply(list).to_dict(); by_t = idx.groupby(tn).apply(list).to_dict()
    rev = lambda i, j: fn[j] == tn[i] and tn[j] == fn[i]
    down = [[j for j in by_f.get(tn[i], []) if j != i and not rev(i, j)] for i in range(len(links))]
    up = [[j for j in by_t.get(fn[i], []) if j != i and not rev(i, j)] for i in range(len(links))]
    return down, up


def neighbors(down, up, k=2):
    """상류·하류 방향으로 k칸 안에 있는 링크(자기 제외)"""
    adj = [sorted(set(d) | set(u)) for d, u in zip(down, up)]; out = []
    for i in range(len(adj)):
        seen = {i}; front = [i]
        for _ in range(k):
            front = [j for v in front for j in adj[v] if j not in seen]; seen.update(front)
        out.append(sorted(seen - {i}))
    return out


def slot(index):
    """하루 안의 10분 칸 번호(0~143)"""
    return ((index.hour * 60 + index.minute) // STEP).values


def hist_avg(F):
    """과거 평균(historical average): 월~목의 같은 10분 칸 평균 속도 (144 × 링크)"""
    tr = F.index < pd.Timestamp(TRAIN_END); s = slot(F.index)
    return np.stack([F.values[tr][s[tr] == k].mean(0) for k in range(1440 // STEP)])


def forecast(F, obs, down, up, h, lag=3):
    """h칸(h×10분) 뒤 속도 예측. 링크마다 네 방법의 금요일 평균 절대 오차(MAE, km/h)를 표로 돌려줌.
    직전 값 · 과거 평균 · 자기 과거(최근 lag칸 + 과거 평균을 쓰는 릿지) · 자기 + 이웃(위에 상류·하류 링크 평균의 최근 lag칸을 더함)"""
    from sklearn.linear_model import Ridge
    V = F.values; HA = hist_avg(F); s = slot(F.index); ha = HA[s]
    nmean = lambda lst: np.stack([V[:, l].mean(1) if len(l) else V[:, i] for i, l in enumerate(lst)], 1)
    DN, UP = nmean(down), nmean(up)
    t_end = int(np.searchsorted(F.index, pd.Timestamp(TRAIN_END))); t_te = int(np.searchsorted(F.index, pd.Timestamp(TEST_DAY) + pd.Timedelta("1D")))
    tr_t = np.arange(lag, t_end - h); te_t = np.arange(t_end, t_te - h); te_t = te_t[obs[te_t + h]]       # 자료가 있던 시각만 평가
    rows = []
    for i in range(V.shape[1]):
        y = V[te_t + h, i]
        def X(tt, nb):
            f = [V[tt - k, i] for k in range(lag)] + [ha[tt + h, i], ha[tt, i]]
            if nb: f += [DN[tt - k, i] for k in range(lag)] + [UP[tt - k, i] for k in range(lag)]
            return np.stack(f, -1)
        r = {"직전 값": np.abs(V[te_t, i] - y).mean(), "과거 평균": np.abs(ha[te_t + h, i] - y).mean()}
        for nm, nb in (("자기 과거", False), ("자기 + 이웃", True)):
            m = Ridge(alpha=1.0).fit(X(tr_t, nb), V[tr_t + h, i]); r[nm] = np.abs(m.predict(X(te_t, nb)) - y).mean()
        rows.append(r)
    return pd.DataFrame(rows, index=F.columns)


def fill(F, obs, nb, frac=0.2, seed=0):
    """자료가 빈 링크 채우기: 링크 frac(20%)를 시드 0으로 골라 숨기고, 금요일 각 시각의 속도를 추정함.
    ① 그 링크의 과거 평균 ② 숨기지 않은 이웃(nb) 링크의 같은 시각 평균 ③ 섞은 선형 모델: 과거 평균 + a × (이웃 현재 − 이웃 과거 평균)
    ③의 계수는 숨기지 않은 링크로 월~목에 학습함. 반환: 링크별 오차 표, 계수, 숨긴 링크 번호"""
    from sklearn.linear_model import Ridge
    V = F.values; HA = hist_avg(F); s = slot(F.index); N = V.shape[1]
    hide = np.zeros(N, bool); hide[np.random.default_rng(seed).choice(N, N // int(round(1 / frac)), replace=False)] = True
    vis_nb = [[j for j in l if not hide[j]] for l in nb]
    tr = (F.index < pd.Timestamp(TRAIN_END)) & obs; te = (F.index.normalize() == pd.Timestamp(TEST_DAY)) & obs
    rtr, rte = np.where(tr)[0], np.where(te)[0]
    Xs, ys = [], []
    for i in np.where(~hide)[0][::3]:
        js = vis_nb[i]
        if js: Xs.append(np.c_[HA[s[rtr], i], V[np.ix_(rtr, js)].mean(1) - HA[np.ix_(s[rtr], js)].mean(1)]); ys.append(V[rtr, i])
    m = Ridge(alpha=1.0).fit(np.vstack(Xs), np.concatenate(ys))
    rows = []
    for i in np.where(hide)[0]:
        js = vis_nb[i]
        if not js: continue
        y = V[rte, i]; ha = HA[s[rte], i]; cur = V[np.ix_(rte, js)].mean(1); anom = cur - HA[np.ix_(s[rte], js)].mean(1)
        mix = m.predict(np.c_[ha, anom]); jam = y < 30
        rows.append({"link": F.columns[i], "과거 평균": np.abs(ha - y).mean(), "이웃 현재 평균": np.abs(cur - y).mean(), "섞은 모델": np.abs(mix - y).mean(),
                     "정체 시각 수": int(jam.sum()), "정체_과거 평균": np.abs(ha - y)[jam].sum(), "정체_섞은 모델": np.abs(mix - y)[jam].sum()})
    return pd.DataFrame(rows).set_index("link"), {"과거 평균": float(m.coef_[0]), "이웃 이탈": float(m.coef_[1]), "절편": float(m.intercept_)}, np.where(hide)[0]
