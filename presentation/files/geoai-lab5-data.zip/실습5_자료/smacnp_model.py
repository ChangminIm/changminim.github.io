# -*- coding: utf-8 -*-
"""SMACNP 국소형 신경망 구조 (Dumitrescu 2026, GMD의 세 경로 구조를 CPU 크기로 줄인 것)
SMACNPLocal()(sc, ec, yc, st, et) → (mu, var)
  sc (B,15,2) 이웃 15곳의 km 좌표 · ec (B,15) 이웃 고도(km) · yc (B,15) 이웃 기온(표준화 또는 잔차)
  st (B,2) 표적 km 좌표 · et (B) 표적 고도(km)
USE_PE = True 로 바꾸면 절대 좌표의 사인·코사인 위치 인코딩을 입력에 더한다. 학습 코드는 들어 있지 않다.
"""
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
K = 15; PE = 32
USE_PE = False
FREQ = torch.tensor(np.geomspace(1 / 800, 1 / 10, PE // 4), dtype=torch.float32)   # 10~800 km 파장


def pos_enc(s):                                     # s: (..., 2) km → 사인·코사인 다중 파장
    a = s[..., :1] * FREQ * 2 * np.pi; b = s[..., 1:] * FREQ * 2 * np.pi
    return torch.cat([a.sin(), a.cos(), b.sin(), b.cos()], -1)


def mlp(i, o, h=128, n=2):
    L = [nn.Linear(i, h), nn.GELU()]
    for _ in range(n - 1): L += [nn.Linear(h, h), nn.GELU()]
    return nn.Sequential(*L, nn.Linear(h, o))


class SMACNPLocal(nn.Module):
    def __init__(s, d=64, heads=4):
        super().__init__()
        fin = 2 + PE + 1                                         # 좌표(정규화)·위치 인코딩·고도
        s.w_enc = mlp(2 + 1, d)                                  # 위치 경로: (좌표, 값) → w
        s.log_temp = nn.Parameter(torch.tensor(np.log(30.0), dtype=torch.float32))   # 라플라스 주의 온도(km)
        s.q_r, s.k_r, s.v_r = mlp(fin, d), mlp(fin, d), mlp(fin + 1 + 3, d)          # 속성 경로 (값 + 상대 Δx·Δy·Δ고도)
        s.att_r = nn.MultiheadAttention(d, heads, batch_first=True)
        s.q_v, s.k_v = mlp(fin, d), mlp(fin + 3, d)               # 분산 경로 (값 없이 배치만)
        s.att_v = nn.MultiheadAttention(d, heads, batch_first=True)
        s.dec_mu = mlp(2 * d + fin, 1); s.dec_var = mlp(d + fin, 1)

    def feats(s, sx, el):
        if not USE_PE: return torch.cat([torch.zeros_like(sx), torch.zeros(*sx.shape[:-1], PE), el[..., None]], -1)
        return torch.cat([sx / 300.0, pos_enc(sx), el[..., None]], -1)

    def forward(s, sc, ec, yc, st, et):
        """sc (B,K,2) 이웃 좌표 km, ec (B,K) 고도, yc (B,K) 표준화 기온, st (B,2), et (B)"""
        rel = torch.cat([(sc - st[:, None]) / 50.0, (ec - et[:, None])[..., None]], -1)
        fc, ft = s.feats(sc, ec), s.feats(st, et)
        w = s.w_enc(torch.cat([(sc - st[:, None]) / 50.0, yc[..., None]], -1))
        dist = (sc - st[:, None]).abs().sum(-1)                  # L1 거리 (p=1)
        a = F.softmax(-dist / s.log_temp.exp(), -1); w_star = (a[..., None] * w).sum(1)
        r_star, _ = s.att_r(s.q_r(ft)[:, None], s.k_r(fc), s.v_r(torch.cat([fc, yc[..., None], rel], -1)))
        v_star, _ = s.att_v(s.q_v(ft)[:, None], s.k_v(torch.cat([fc, rel], -1)), s.k_v(torch.cat([fc, rel], -1)))
        r_star, v_star = r_star[:, 0], v_star[:, 0]
        mu = s.dec_mu(torch.cat([r_star, w_star, ft], -1))[:, 0]
        var = F.softplus(s.dec_var(torch.cat([v_star, ft], -1))[:, 0]) + 2e-4
        return mu, var




# ── 혼합형 학습·예측 (난수 고정: 모든 학생이 같은 결과) ───────────────────────
torch.use_deterministic_algorithms(True)


def _trend(v, ctx, E, X, Y):
    """그날 입력 관측소로 고도·x·y 선형 추세를 맞춰 모든 관측소의 추세값을 돌려줌"""
    A = np.column_stack([np.ones(len(ctx)), E[ctx], X[ctx], Y[ctx]])
    beta = np.linalg.lstsq(A, v[ctx], rcond=None)[0]
    return np.column_stack([np.ones(len(E)), E, X, Y]) @ beta


def _batch(v, ctx, tgt, E, X, Y, SX, SE):
    ctx = ctx[~np.isnan(v[ctx])]; tgt = tgt[~np.isnan(v[tgt])]
    tr = _trend(v, ctx, E, X, Y); r = v - tr
    d = np.hypot(X[tgt, None] - X[None, ctx], Y[tgt, None] - Y[None, ctx])
    nb = ctx[np.argsort(d, 1, kind="stable")[:, :K]]
    return (SX[nb], SE[nb], torch.tensor(r[nb], dtype=torch.float32), SX[tgt], SE[tgt],
            torch.tensor(r[tgt], dtype=torch.float32), tgt, tr[tgt])


def train_hybrid(V, X, Y, E, input_idx, train_days, steps=1000, days_per_step=8, threads=4, verbose=True):
    """V: (날짜, 관측소) 기온 배열, X·Y: km 좌표, E: 고도(km), input_idx: 숨기지 않은 관측소 번호,
    train_days: 학습 기간 날짜 번호. 입력 관측소의 15%(씨드 1)는 검증용으로 빼고 학습함. 반환: (모델, 학습 기록)"""
    torch.set_num_threads(threads); torch.manual_seed(0)
    rng = np.random.default_rng(0)
    val_st = np.sort(np.random.default_rng(1).choice(input_idx, len(input_idx) * 15 // 100, replace=False))
    fit_st = np.setdiff1d(input_idx, val_st)
    val_days = np.sort(np.random.default_rng(2).choice(train_days, 30, replace=False))
    SX = torch.tensor(np.column_stack([X, Y]), dtype=torch.float32); SE = torch.tensor(E, dtype=torch.float32)
    net = SMACNPLocal(); opt = torch.optim.AdamW(net.parameters(), 1e-3, weight_decay=1e-5)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps)
    best, state, log = 1e9, None, []
    for step in range(steps):
        net.train(); loss = 0
        for day in rng.choice(train_days, days_per_step):
            perm = rng.permutation(fit_st); h = len(perm) // 2
            sc, ec, yc, st, et, yt, _, _ = _batch(V[day], perm[:h], perm[h:], E, X, Y, SX, SE)
            mu, var = net(sc, ec, yc, st, et)
            loss = loss + 0.5 * (torch.log(var) + (yt - mu) ** 2 / var).mean()
        opt.zero_grad(); (loss / days_per_step).backward(); nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); sched.step()
        if step % 250 == 0 or step == steps - 1:
            net.eval(); errs = []
            with torch.no_grad():
                for day in val_days:
                    sc, ec, yc, st, et, yt, _, _ = _batch(V[day], fit_st, val_st, E, X, Y, SX, SE)
                    errs.append((net(sc, ec, yc, st, et)[0] - yt).abs().numpy())
            cur = float(np.concatenate(errs).mean()); log.append({"step": step, "val_MAE": round(cur, 4)})
            if cur < best:
                best, state = cur, {k: t.clone() for k, t in net.state_dict().items()}
            if verbose:
                print(f"step {step}: 검증 관측소 MAE {cur:.4f}")
    net.load_state_dict(state); net.eval()
    return net, log


def predict_hybrid(net, v, input_idx, target_idx, X, Y, E):
    """하루 기온 v(관측소 순서)와 입력 관측소로 target_idx의 기온을 예측. 반환: (관측이 있는 표적 번호, 평균, 표준편차)"""
    SX = torch.tensor(np.column_stack([X, Y]), dtype=torch.float32); SE = torch.tensor(E, dtype=torch.float32)
    with torch.no_grad():
        sc, ec, yc, st, et, _, tgt, tr = _batch(v, np.asarray(input_idx), np.asarray(target_idx), E, X, Y, SX, SE)
        mu, var = net(sc, ec, yc, st, et)
    return tgt, mu.numpy() + tr, np.sqrt(var.numpy())
