# -*- coding: utf-8 -*-
"""8주차 실습 1 도우미: 시군구 우울 패널로 XGBoost를 학습하고 SHAP·LIME·GeoShapley로 설명
난수가 들어가는 부분(교차검증 분할, GeoShapley 배경 자료, LIME 표본)과 모델 설정을 고정해 모든 학생이 같은 값을 얻게 함.
"""
from pathlib import Path
import numpy as np
import pandas as pd

VARS = ["ndvi", "single_young", "welfare_rate", "old_house", "fiscal_ind"]
FEATS = VARS + ["year", "x_km", "y_km"]                    # 좌표는 맨 뒤 두 열에 둠 (GeoShapley 규칙)
LABEL = {"ndvi": "녹지(NDVI)", "single_young": "청년 1인 가구", "welfare_rate": "기초생활수급", "old_house": "노후 주택",
         "fiscal_ind": "재정자립도", "year": "연도", "x_km": "가로 좌표", "y_km": "세로 좌표"}
TARGET = "dep_ma3"                                          # 우울감 경험률(%, 3년 이동평균)


def load(data_dir="data"):
    """패널(229 시군구 × 2016~2024년, 2,052행)과 시군구 경계(GeoDataFrame)를 읽음"""
    import geopandas as gpd
    d = Path(data_dir)
    df = pd.read_csv(d / "depression_panel.csv", encoding="utf-8-sig", dtype={"SIG_CD": str})
    gdf = gpd.read_file(d / "sigungu229.geojson")
    gdf["SIG_CD"] = gdf.SIG_CD.astype(str)
    return df, gdf


def make_model():
    """모든 학생이 같은 XGBoost를 쓰도록 설정을 고정함. 행·열 표본 추출을 쓰지 않아 스레드 수와 무관하게 같은 결과가 나옴"""
    from xgboost import XGBRegressor
    return XGBRegressor(n_estimators=300, max_depth=4, learning_rate=0.05, min_child_weight=3, subsample=1.0, colsample_bytree=1.0,
                        importance_type="gain", tree_method="hist", random_state=0, n_jobs=1)


def cv_score(df, cols, by="random"):
    """5겹 교차검증으로 XGBoost와 선형회귀(OLS)의 R²·MAE(%p)를 구함.
    by='random': 행을 무작위로 나눔(시드 0). by='district': 같은 시군구의 9년을 한 겹에 묶어, 처음 보는 시군구를 맞히게 함"""
    from sklearn.model_selection import KFold, GroupKFold
    from sklearn.linear_model import LinearRegression
    from sklearn.metrics import r2_score, mean_absolute_error
    X = df[cols].values; y = df[TARGET].values
    out = {}
    for name, mk in (("xgb", make_model), ("ols", LinearRegression)):
        pred = np.zeros(len(y))
        sp = (GroupKFold(5).split(X, y, df.SIG_CD.values) if by == "district" else KFold(5, shuffle=True, random_state=0).split(X))
        for tr, te in sp:
            pred[te] = mk().fit(X[tr], y[tr]).predict(X[te])
        out[name + "_R2"] = float(r2_score(y, pred)); out[name + "_MAE"] = float(mean_absolute_error(y, pred))
    return out


def lime_explain(model, X, row, seed=0, num_samples=5000):
    """LIME으로 X의 row번째 행을 설명함. 그 행 주변에서 표본 num_samples개를 만들어 모델에 넣고, 가까운 표본에 큰 가중치를 주어 선형 모델을 맞춤.
    반환: 표(변수, 조건, 가중치) — 가중치는 '이 변수가 이 구간에 있을 때 예측이 얼마나 달라지나(%p)'. attrs에 국지 R²와 국지 선형 모델의 예측"""
    from lime.lime_tabular import LimeTabularExplainer
    le = LimeTabularExplainer(X.values, feature_names=list(X.columns), mode="regression", random_state=seed)
    e = le.explain_instance(X.values[row], model.predict, num_features=X.shape[1], num_samples=num_samples)
    pairs = dict(e.as_map()[1]); names = e.domain_mapper.discretized_feature_names
    t = pd.DataFrame({"변수": list(X.columns), "조건": [names[i] for i in range(X.shape[1])], "가중치": [pairs[i] for i in range(X.shape[1])]})
    t.attrs["local_r2"] = float(e.score); t.attrs["local_pred"] = float(np.ravel(e.local_pred)[0])
    return t


def background(X, n=100):
    """GeoShapley가 '이 변수를 모를 때'를 흉내 내려고 쓰는 배경 자료. 행 n개를 시드 0으로 뽑음"""
    return X.sample(n, random_state=0)


def geoshap(model, X):
    """GeoShapley 값: 예측 = 기준값 + 위치 효과 + 변수 주효과 합 + (변수×위치) 합.
    X의 마지막 두 열이 좌표여야 함. 변수가 8개 이하라 모든 조합을 다 계산하므로 난수가 없음. 약 1분.
    반환 dict: base(기준값), geo(위치 효과, n), primary(주효과 표, n×변수), inter(변수×위치 표, n×변수)"""
    from geoshapley import GeoShapleyExplainer
    rs = GeoShapleyExplainer(model.predict, background(X).values).explain(X, n_jobs=1)
    names = list(X.columns[:-2])
    return {"base": float(rs.base_value), "geo": np.asarray(rs.geo), "primary": pd.DataFrame(rs.primary, columns=names, index=X.index),
            "inter": pd.DataFrame(rs.geo_intera, columns=names, index=X.index)}


def local_slope(df, gs, var, year=2019):
    """GeoShapley 기여에서 지역별 기울기를 구함 (geoshapley 패키지의 get_svc와 같은 방식).
    1) 그해 행의 기여(주효과 + 변수×위치)를 변수 값에 대해 지리가중회귀(GWR)로 맞춤: 시군구마다 가까운 이웃만으로 '변수가 1 늘 때 기여가 얼마나 달라지나'를 구함
    2) 이웃 수는 AICc로 고름(최소 20)  3) 지난주 MGWR 계수와 견줄 수 있게 표준화 단위(변수 1 표준편차당 우울 표준편차)로 바꿈
    반환: 표(SIG_CD, slope), 이웃 수"""
    from mgwr.sel_bw import Sel_BW
    from mgwr.gwr import GWR
    m = (df.year == year).values
    contrib = (gs["primary"][var] + gs["inter"][var]).values[m]; x = df[var].values[m].astype(float)
    yy = (contrib - contrib.mean()).reshape(-1, 1); xx = (x - x.mean()).reshape(-1, 1)
    coords = df.loc[m, ["x_km", "y_km"]].values.astype(float)
    bw = Sel_BW(coords, yy, xx, constant=False).search(bw_min=20)
    slope = GWR(coords, yy, xx, bw, constant=False).fit().params[:, 0] * df[var].std(ddof=0) / df[TARGET].std(ddof=0)
    return pd.DataFrame({"SIG_CD": df.SIG_CD.values[m], "slope": slope}), float(bw)


def mgwr_2019(df):
    """지난주 실습과 같은 설정의 2019년 MGWR(적응형 bisquare, AICc, 최소 이웃 20). 변수는 전체 패널 기준으로 표준화.
    반환 dict: codes(시군구 코드), betas(n×6, 첫 열 절편, 표준화 계수), bw(변수별 이웃 수), R2. 약 1분"""
    from mgwr.sel_bw import Sel_BW
    from mgwr.gwr import MGWR
    X = df[VARS].values.astype(float); X = (X - X.mean(0)) / X.std(0)
    y = df[[TARGET]].values.astype(float); y = (y - y.mean()) / y.std()
    m = (df.year == 2019).values; C = df.loc[m, ["x_km", "y_km"]].values
    sel = Sel_BW(C, y[m], X[m], kernel="bisquare", fixed=False, multi=True)
    bw = sel.search(criterion="AICc", multi_bw_min=[20])
    r = MGWR(C, y[m], X[m], sel, kernel="bisquare", fixed=False).fit()
    return {"codes": df.SIG_CD[m].tolist(), "betas": r.params, "bw": np.asarray(bw).ravel(), "R2": float(r.R2)}
