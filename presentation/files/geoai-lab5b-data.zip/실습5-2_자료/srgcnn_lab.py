# -*- coding: utf-8 -*-
"""6주차 실습(2) 도우미: 모든 학생이 같은 결과를 얻도록 난수가 개입하는 부분을 고정한 함수 모음
- split(n, ratio)            : 학습·숨김 숙소 고정 분할 (np.random.default_rng(0))
- knn_graph(coords_km, k)    : kNN 그래프 → (그래프 합성곱용 정규화 행렬, 행 표준화 W, 0/1 인접행렬)
- train_srgcnn(...)          : SRGCNN · SRGCNN-GW 학습 (torch.manual_seed(0), 결정적 연산, 스레드 1개)
모델 식은 Zhu 외(2022, GeoInformatica)와 교재 7.4.3을 따라 새로 작성함.
  SRGCNN     : H' = Â H Θ
  SRGCNN-GW  : H' = Â (H ⊙ Θ_local) Θ      (Θ_local: 지점마다 다른 가중치)
"""
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from scipy import sparse
from scipy.spatial import cKDTree

torch.set_num_threads(1)
torch.use_deterministic_algorithms(True)


def split(n, ratio, seed=0):
    """학습 지점과 숨긴 지점의 번호(정렬됨)"""
    tr = np.sort(np.random.default_rng(seed).choice(n, int(n * ratio), replace=False))
    return tr, np.setdiff1d(np.arange(n), tr)


def knn_graph(coords_km, k=10):
    """대칭 kNN 그래프. 반환: (Â 대칭 정규화 + 자기 연결, 행 표준화 W, 0/1 인접행렬 A)"""
    n = len(coords_km)
    _, idx = cKDTree(coords_km).query(coords_km, k=k + 1)
    A = sparse.coo_matrix((np.ones(n * k), (np.repeat(np.arange(n), k), idx[:, 1:].ravel())), shape=(n, n)).tocsr()
    A = ((A + A.T) > 0).astype(float)
    At = A + sparse.eye(n); Dm = sparse.diags(np.asarray(At.sum(1)).ravel() ** -0.5)
    A_hat = (Dm @ At @ Dm).tocsr()
    W = sparse.diags(1 / np.asarray(A.sum(1)).ravel()) @ A
    return A_hat, W, A


class _GC(nn.Module):
    def __init__(self, fi, fo, n, adj, gw, act):
        super().__init__()
        self.adj, self.act = adj, act
        self.W = nn.Linear(fi, fo)
        self.gw = nn.Parameter(torch.ones(n, fi)) if gw else None          # SRGCNN-GW 지점별 가중치 (공식 데모처럼 1로 시작)

    def forward(self, h):
        if self.gw is not None:
            h = h * self.gw
        out = torch.sparse.mm(self.adj, self.W(h))
        return F.relu(out) if self.act else out


class SRGCNN(nn.Module):
    """두 층 그래프 합성곱 회귀. kind: 'base'(SRGCNN) · 'gw'(SRGCNN-GW)"""
    def __init__(self, n_feat, n, adj, kind="base", hidden=16):
        super().__init__()
        gw = kind == "gw"
        self.l1 = _GC(n_feat, hidden, n, adj, gw, True)
        self.l2 = _GC(hidden, 1, n, adj, gw, False)

    def forward(self, x):
        return self.l2(self.l1(x)).squeeze(-1)


def train_srgcnn(X, y, A_hat, train_idx, kind="base", epochs=3000, lr=None, verbose=False):
    """학습 지점의 20%(default_rng(1))로 조기 종료할 시점을 고르고, 전체 지점의 예측값을 돌려줌.
    반환: (예측값 배열, 학습 기록 [{epoch, train_MAE, val_MAE}])"""
    torch.manual_seed(0)
    n = len(y)
    va = np.sort(np.random.default_rng(1).choice(train_idx, len(train_idx) // 5, replace=False))
    fit = np.setdiff1d(train_idx, va)
    Ah = A_hat.tocoo()
    adj = torch.sparse_coo_tensor(np.vstack([Ah.row, Ah.col]), Ah.data, (n, n)).float().coalesce()
    xt, yt = torch.tensor(X, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)
    ybar = float(y[fit].mean())
    m = SRGCNN(X.shape[1], n, adj, kind)
    opt = torch.optim.Adam(m.parameters(), lr=lr or (3e-3 if kind == "gw" else 1e-2), weight_decay=1e-4)
    best, state, log = 1e9, None, []
    for ep in range(epochs):
        m.train(); opt.zero_grad()
        loss = F.mse_loss((m(xt) + ybar)[fit], yt[fit]); loss.backward(); opt.step()
        if ep % 20 == 0:
            m.eval()
            with torch.no_grad():
                o = m(xt) + ybar
                tr_mae, va_mae = F.l1_loss(o[fit], yt[fit]).item(), F.l1_loss(o[va], yt[va]).item()
            log.append({"epoch": ep, "train_MAE": tr_mae, "val_MAE": va_mae})
            if va_mae < best:
                best, state = va_mae, {k: t.clone() for k, t in m.state_dict().items()}
            if verbose and ep % 500 == 0:
                print(f"epoch {ep}: 학습 MAE {tr_mae:.4f} · 검증 MAE {va_mae:.4f}")
    m.load_state_dict(state); m.eval()
    with torch.no_grad():
        return (m(xt) + ybar).numpy(), log


def sar_predict(X, y, W, coords_km, train_idx, durbin=False, k=10):
    """SAR(durbin=False) 또는 SDM(durbin=True)을 학습 지점으로 최대우도 추정하고,
    전체 그래프에서 축약형 ŷ = (I - ρW)^-1 (β0 + Xβ [+ WXθ]) 로 모든 지점을 예측. 반환: (예측값, ρ)"""
    import spreg, libpysal
    from scipy.sparse import linalg as sla
    w = libpysal.weights.KNN.from_array(coords_km[train_idx], k=k); w.transform = "r"
    WX = W @ X
    Xd = np.hstack([X, WX])[train_idx] if durbin else X[train_idx]
    m = spreg.ML_Lag(y[train_idx][:, None], Xd, w=w, method="LU")
    b = np.asarray(m.betas).ravel(); rho = float(b[-1])
    Xf = np.hstack([X, WX]) if durbin else X
    n = len(y)
    return sla.spsolve((sparse.eye(n) - rho * W).tocsc(), b[0] + Xf @ b[1:-1]), rho


def gwr_predict(coords_km, X, y, train_idx):
    """GWR(적응형 bisquare 커널, AICc로 대역폭 선택)을 학습 지점으로 맞추고,
    숨긴 지점은 가까운 학습 지점 bw개의 가중최소제곱으로 예측. 반환: (예측값, 대역폭=이웃 수)"""
    from mgwr.gwr import GWR
    from mgwr.sel_bw import Sel_BW
    n = len(y); tr = train_idx; te = np.setdiff1d(np.arange(n), tr)
    bw = Sel_BW(coords_km[tr], y[tr][:, None], X[tr], kernel="bisquare", fixed=False).search(criterion="AICc")
    p = np.empty(n)
    p[tr] = GWR(coords_km[tr], y[tr][:, None], X[tr], bw, kernel="bisquare", fixed=False).fit().predy.ravel()
    kk = int(bw); dist, idx = cKDTree(coords_km[tr]).query(coords_km[te], k=kk + 1)
    Xa = np.column_stack([np.ones(n), X]); Xt, yt = Xa[tr], y[tr]
    for j, t in enumerate(te):
        h = dist[j, -1]; ii = idx[j, :kk]; wv = (1 - (dist[j, :kk] / h) ** 2) ** 2
        Xw = Xt[ii] * wv[:, None]
        p[t] = Xa[t] @ np.linalg.solve(Xw.T @ Xt[ii] + 1e-8 * np.eye(Xa.shape[1]), Xw.T @ yt[ii])
    return p, int(bw)
