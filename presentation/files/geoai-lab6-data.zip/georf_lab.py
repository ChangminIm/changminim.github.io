# -*- coding: utf-8 -*-
"""7주차 실습 1 도우미: 공주 Sentinel-2 농경지 분류에서 공간을 다루는 방식 비교와 구역별 공정성 평가
난수가 들어가는 부분(표본 추출, 학습·평가 분할, RF, GeoRF)을 함수로 고정해 모든 학생이 같은 값을 얻게 함.
"""
import os, re, sys, shutil
from pathlib import Path
import numpy as np

WC_MAP = {10: 0, 20: 1, 30: 1, 60: 1, 40: 2, 50: 3, 80: 4, 90: 4, 95: 4, 100: 1, 70: 1}   # 2 = 농경지
PIX_KM = 0.01                                                                            # 화소 10 m
GEORF_COMMIT = "af5af0d961f7911ac08b73806f20f4b298fd07f4"


def load_gongju(data_dir=".", n=60000):
    """kongju_s2.tif·kongju_wc.tif에서 화소 n개를 고정 씨드(0)로 뽑음.
    반환: X(n×5: B2,B3,B4,B8,NDVI), y(농경지=1), loc(n×2, km), extent(가로 km, 세로 km)"""
    import rasterio
    d = Path(data_dir)
    with rasterio.open(d / "kongju_s2.tif") as r:
        s2 = r.read().astype("float32") / 10000.0
    with rasterio.open(d / "kongju_wc.tif") as r:
        wc = r.read(1)
    lab = np.full(wc.shape, 255, "uint8")
    for k, v in WC_MAP.items():
        lab[wc == k] = v
    H, W = wc.shape
    ndvi = (s2[3] - s2[2]) / (s2[3] + s2[2] + 1e-6)
    F = np.concatenate([s2, ndvi[None]], 0)
    rng = np.random.default_rng(0)
    rr, cc = np.where(lab != 255)
    pick = rng.choice(len(rr), n, replace=False)
    rr, cc = rr[pick], cc[pick]
    X = F[:, rr, cc].T.astype("float64")
    y = (lab[rr, cc] == 2).astype(int)
    loc = np.column_stack([cc * PIX_KM, (H - 1 - rr) * PIX_KM])
    return X, y, loc, (W * PIX_KM, H * PIX_KM)


def split(n, test_ratio=0.3):
    """학습·평가 화소를 고정 씨드(0)로 나눔. 반환: 학습 번호, 평가 번호"""
    idx = np.random.default_rng(0).permutation(n)
    k = int(round(n * test_ratio))
    return np.sort(idx[k:]), np.sort(idx[:k])


def make_rf(n_estimators=200):
    """모든 RF가 같은 설정을 쓰도록 고정함 (씨드 0)"""
    from sklearn.ensemble import RandomForestClassifier
    return RandomForestClassifier(n_estimators=n_estimators, min_samples_leaf=1, random_state=0, n_jobs=-1)


def region_id(loc, k, extent):
    """영역을 k×k 격자로 나눈 구역 번호"""
    qx = np.minimum((loc[:, 0] / extent[0] * k).astype(int), k - 1)
    qy = np.minimum((loc[:, 1] / extent[1] * k).astype(int), k - 1)
    return qy * k + qx


def region_f1(y_true, y_pred, loc, k, extent, min_pos=20):
    """k×k 구역별 F1. 농경지 화소가 min_pos개 미만인 구역은 뺌. 반환: {구역번호: F1}"""
    from sklearn.metrics import f1_score
    rg = region_id(loc, k, extent)
    out = {}
    for r in np.unique(rg):
        m = rg == r
        if y_true[m].sum() >= min_pos:
            out[int(r)] = float(f1_score(y_true[m], y_pred[m], zero_division=0))
    return out


def fairness(y_true, y_pred, loc, extent, ks=(4, 6, 8)):
    """SPAD식 평가: 격자 크기를 바꿔 가며 구역별 F1의 표준편차와 최저값을 계산함"""
    res = {}
    for k in ks:
        f = np.array(list(region_f1(y_true, y_pred, loc, k, extent).values()))
        res[f"{k}x{k}"] = {"sd": float(f.std()), "min": float(f.min()), "n": int(len(f))}
    res["mean_sd"] = float(np.mean([res[f"{k}x{k}"]["sd"] for k in ks]))
    return res




def setup_georf(repo_dir="STAR", work_dir="georf_work", max_depth=3, step_km=1.0):
    """공식 STAR 저장소의 Tree-based-models를 작업 폴더로 복사하고 설정을 바꿔 불러올 준비를 함"""
    src = Path(repo_dir) / "Tree-based-models"
    work = Path(work_dir).resolve()
    if not work.exists():
        shutil.copytree(src, work)
    cfg = (work / "config.py").read_text(encoding="utf-8")
    cfg = re.sub(r"^N_JOBS = .*$", "N_JOBS = 4", cfg, flags=re.M)
    cfg = re.sub(r"^MAX_DEPTH = .*$", f"MAX_DEPTH = {max_depth}", cfg, flags=re.M)
    cfg = re.sub(r"^STEP_SIZE = .*$", f"STEP_SIZE = {step_km}#km", cfg, flags=re.M)
    (work / "config.py").write_text(cfg, encoding="utf-8")
    hp = (work / "helper.py").read_text(encoding="utf-8")        # pandas 3에서는 체인 할당이 원본을 바꾸지 않아 의도대로 고침
    hp = hp.replace("s_branch[''][:gid_list.shape[0]] = gid_list", "s_branch.loc[:gid_list.shape[0] - 1, ''] = gid_list")
    (work / "helper.py").write_text(hp, encoding="utf-8")
    if str(work) not in sys.path:
        sys.path.insert(0, str(work))
    return work


def run_georf(X, y, loc, tr, te, work):
    """GeoRF 학습과 예측. 그룹 = 1 km 격자. 반환: 평가 화소 예측, 전체 화소의 분할 번호(문자열), 분할 개수"""
    cwd = os.getcwd(); os.chdir(work)
    try:
        from GeoRF import GeoRF
        from customize import GroupGenerator
        from helper import get_spatial_range, get_X_branch_id_by_group
        import config as C
        xmin, xmax, ymin, ymax = get_spatial_range(loc)
        grp = GroupGenerator(xmin, xmax, ymin, ymax, C.STEP_SIZE).get_groups(loc.copy())
        np.random.seed(0)
        model = GeoRF(min_model_depth=C.MIN_DEPTH, max_model_depth=C.MAX_DEPTH, n_jobs=C.N_JOBS)
        model.fit(X[tr], y[tr], grp[tr], val_ratio=C.VAL_RATIO)
        pred = model.predict(X[te], grp[te])
        branch = get_X_branch_id_by_group(grp, model.s_branch)
    finally:
        os.chdir(cwd)
    return np.asarray(pred).astype(int), branch, len(np.unique(branch))
