# -*- coding: utf-8 -*-
"""9주차 실습 도우미: 도시대기 측정소 517곳의 2024년 PM10 연평균을 랜덤포레스트로 예측하고, 무작위 교차검증과 공간 교차검증(spatial cross-validation)을 비교함
교재 Ch.10의 네 방법: 군집 기반(K-평균), 격자 기반(3×3), 지리 속성 기반(시도), 공간 LOO(버퍼). 분할과 모델의 난수를 모두 고정해 모든 학생이 같은 값을 얻게 함.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ENV = ["elev", "coast_km", "popden", "apt"]
FEATS = ["x_km", "y_km"] + ENV
LABEL = {"x_km": "가로 좌표", "y_km": "세로 좌표", "elev": "고도", "coast_km": "해안까지 거리", "popden": "인구밀도(log)", "apt": "아파트 비율"}
TARGET = "pm10"                                             # 2024년 PM10 연평균 (µg/m³)
METHODS = {"random": "무작위", "sido": "시도", "kmeans": "K-평균 군집", "grid": "격자 3×3"}


def load(data_dir="data"):
    """측정소 표(517행)와 시군구 경계(GeoDataFrame, EPSG:5179)를 읽음"""
    import geopandas as gpd
    d = Path(data_dir)
    df = pd.read_csv(d / "pm10_stations.csv", encoding="utf-8-sig", dtype={"SIG_CD": str})
    gdf = gpd.read_file(d / "sigungu229.geojson"); gdf["SIG_CD"] = gdf.SIG_CD.astype(str)
    return df, gdf


def make_model(kind="rf"):
    """kind='rf': 랜덤포레스트(300그루, 잎 최소 2개, 시드 0). 결과는 스레드 수와 무관하게 같음. kind='ols': 선형회귀"""
    if kind == "rf":
        from sklearn.ensemble import RandomForestRegressor
        return RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=0, n_jobs=-1)
    from sklearn.linear_model import LinearRegression
    return LinearRegression()


def folds(df, method):
    """측정소마다 평가 쪽이 되는 겹(fold) 번호(0부터).
    random: 무작위 10겹(시드 0) · kmeans: 좌표를 K-평균으로 10군집(시드 0) · grid: 좌표 범위를 3×3으로 나눔(빈 칸 빠짐) · sido: 시도 17개가 각각 한 겹"""
    from sklearn.model_selection import KFold
    n = len(df); xy = df[["x_km", "y_km"]].values; f = np.zeros(n, int)
    if method == "random":
        for k, (_, te) in enumerate(KFold(10, shuffle=True, random_state=0).split(xy)): f[te] = k
    elif method == "kmeans":
        from sklearn.cluster import KMeans
        f = KMeans(n_clusters=10, n_init=10, random_state=0).fit_predict(xy)
    elif method == "grid":
        gx = np.minimum((3 * (xy[:, 0] - xy[:, 0].min()) / np.ptp(xy[:, 0])).astype(int), 2)
        gy = np.minimum((3 * (xy[:, 1] - xy[:, 1].min()) / np.ptp(xy[:, 1])).astype(int), 2)
        f = pd.factorize(gy * 3 + gx, sort=True)[0]
    elif method == "sido":
        f = pd.factorize(df.sido, sort=True)[0]
    else:
        raise ValueError(method)
    return np.asarray(f)


def cv(df, cols, fold, kind="rf"):
    """겹 번호대로 학습·평가를 되풀이해 모든 측정소의 '평가 쪽 예측'을 모음. 반환: R2, RMSE, MAE(µg/m³), 겹 수, pred"""
    from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
    X = df[cols].values; y = df[TARGET].values; pred = np.zeros(len(y))
    for k in np.unique(fold):
        te = fold == k
        pred[te] = make_model(kind).fit(X[~te], y[~te]).predict(X[te])
    return {"R2": float(r2_score(y, pred)), "RMSE": float(np.sqrt(mean_squared_error(y, pred))), "MAE": float(mean_absolute_error(y, pred)),
            "folds": int(len(np.unique(fold))), "pred": pred}


def dist_matrix(df):
    """측정소 사이 거리(km) 행렬 (자기 자신은 0)"""
    xy = df[["x_km", "y_km"]].values
    return np.hypot(xy[:, None, 0] - xy[None, :, 0], xy[:, None, 1] - xy[None, :, 1])


def buffer_loo(df, cols, r_km, kind="rf", n=100, seed=0):
    """공간 LOO(spatial leave-one-out): 측정소 n곳(시드 0으로 고정)을 하나씩 평가 쪽에 두고, 그 측정소에서 r_km 안의 다른 측정소를 학습에서 뺌(버퍼).
    r_km=0이면 그 측정소만 뺌. 반환: R2, RMSE, 학습에서 뺀 측정소 수의 평균(자기 제외), 평가한 측정소 번호"""
    from sklearn.metrics import r2_score, mean_squared_error
    D = dist_matrix(df); pick = np.sort(np.random.default_rng(seed).choice(len(df), n, replace=False))
    X = df[cols].values; y = df[TARGET].values; ps = []; drop = []
    for i in pick:
        tr = D[i] > r_km; tr[i] = False
        ps.append(make_model(kind).fit(X[tr], y[tr]).predict(X[i:i + 1])[0]); drop.append(int((~tr).sum()) - 1)
    ps = np.array(ps)
    return {"R2": float(r2_score(y[pick], ps)), "RMSE": float(np.sqrt(mean_squared_error(y[pick], ps))), "dropped": float(np.mean(drop)), "pick": pick, "pred": ps}


def nearest_train_km(df, fold):
    """측정소마다 '학습 쪽에 있는 가장 가까운 측정소'까지 거리(km)"""
    D = dist_matrix(df); out = np.zeros(len(df))
    for k in np.unique(fold):
        te = fold == k; out[te] = D[np.ix_(te, ~te)].min(1)
    return out


def grid_points(gdf, step_km=1.0):
    """시군구 경계 안의 격자점(간격 step_km) 좌표 표 x_km, y_km. 지도를 만들 때 예측할 곳"""
    import geopandas as gpd
    x0, y0, x1, y1 = gdf.total_bounds; s = step_km * 1000
    gx, gy = np.meshgrid(np.arange(x0 + s / 2, x1, s), np.arange(y0 + s / 2, y1, s))
    pts = gpd.GeoDataFrame(geometry=gpd.points_from_xy(gx.ravel(), gy.ravel()), crs=gdf.crs)
    inside = gpd.sjoin(pts, gdf[["geometry"]], predicate="within"); inside = inside[~inside.index.duplicated()]
    return pd.DataFrame({"x_km": inside.geometry.x.values / 1000, "y_km": inside.geometry.y.values / 1000})


def nearest_station_km(df, pts):
    """격자점마다 가장 가까운 측정소까지 거리(km)"""
    from scipy.spatial import cKDTree
    return cKDTree(df[["x_km", "y_km"]].values).query(pts[["x_km", "y_km"]].values)[0]
